# app/__init__.py

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from .routes import register_blueprints  # Ensure this function is defined in app/routes/__init__.py

# Instantiate the SQLAlchemy ORM instance
db = SQLAlchemy()


def create_app():
    """
    Application factory function to create and configure the Flask app.
    """
    # Instantiate the Flask application
    app = Flask(__name__)

    # Configure the Flask application (this should be adjusted according to your configuration)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Initialize the app with the database setup
    db.init_app(app)

    # Register blueprints for routing (make sure that register_blueprints is implemented correctly)
    register_blueprints(app)

    # Additional configuration and initialization can be done here

    return app
