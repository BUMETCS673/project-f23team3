from app import db

# Define a model class for the 'orders' table.
class Order(db.Model):
    __tablename__ = 'orders'  # Specify the table name for SQLAlchemy.

    # Define columns according to the schema provided.
    id = db.Column(db.Integer, primary_key=True)
    table_id = db.Column(db.Integer, db.ForeignKey('dining_tables.id'), nullable=False)
    date = db.Column(db.Text, nullable=False)
    status = db.Column(db.Text, nullable=False)
    payment = db.Column(db.Text)
    request = db.Column(db.Text)

    # Relationships can be defined here if needed, for example:
    # dining_table = db.relationship('DiningTable', back_populates='orders')

    # Method to serialize the Order object to a dictionary, for easy JSON conversion.
    def to_dict(self):
        return {
            'id': self.id,
            'table_id': self.table_id,
            'date': self.date,
            'status': self.status,
            'payment': self.payment,
            'request': self.request
        }
