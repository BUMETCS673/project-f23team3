from app import db

# Define a model class for the 'dishes' table.
class Dish(db.Model):
    __tablename__ = 'dishes'  # Specify the table name for SQLAlchemy.

    # Define columns according to the schema provided.
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Text, nullable=False)
    description = db.Column(db.Text)
    cost = db.Column(db.Real, nullable=False)
    pic_url = db.Column(db.Text)
    num_left = db.Column(db.Integer)

    # Relationships can be defined here if needed, for example:
    # compositions = db.relationship('Composition', back_populates='dish')

    # Method to serialize the Dish object to a dictionary, for easy JSON conversion.
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'cost': self.cost,
            'pic_url': self.pic_url,
            'num_left': self.num_left
        }
