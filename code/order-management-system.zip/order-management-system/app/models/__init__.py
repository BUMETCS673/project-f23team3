# app/models/__init__.py
# Import the db instance from the parent module (app)
from .. import db

# Now you can import your models, and they will have access to the db instance
from .customers import Customer
from .orders import Order
from .dishes import Dish

# You can use db to perform database operations such as creating tables


def init_app(app):
    with app.app_context():
        db.create_all()
