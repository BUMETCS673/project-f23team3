from app import db

# Define a model class for the 'customers' table using the SQLAlchemy ORM.
class Customer(db.Model):
    __tablename__ = 'customers'  # Specify the table name.

    # Define columns for the table.
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Text, nullable=False)
    email = db.Column(db.Text, nullable=False)
    # Additional fields and relationships can be defined here.
