# app/routes/__init__.py

# Import the blueprint objects from the individual route modules.
# Ensure that the route modules actually exist and are named correctly.
from .order_routes import order_bp
from .dish_routes import dish_bp
# Continue importing other Blueprints as you create them.

# This function should be called in your main app/__init__.py file to register the blueprints.
def register_blueprints(app):
    """
    Registers all blueprint modules with the Flask application.

    Args:
        app (Flask): The Flask application instance.
    """
    app.register_blueprint(order_bp)
    app.register_blueprint(dish_bp)
    # Register additional blueprints as they are created.

