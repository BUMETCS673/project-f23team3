# app/routes/dish_routes.py
from flask import Blueprint, jsonify

# Define a Blueprint for dish-related routes
dish_bp = Blueprint('dish', __name__)

# Define a route within this blueprint


@dish_bp.route('/dishes')
def get_dishes():
    # Placeholder response to demonstrate route functionality
    return jsonify({'message': 'Here are the dishes.'})
