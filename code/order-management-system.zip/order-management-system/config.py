import os

# Determine the absolute path of the current directory.
basedir = os.path.abspath(os.path.dirname(__file__))

# Define a configuration class for Flask application settings.


class Config:
    # Construct the SQLite database URI using a relative path.
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'app.db')
    # Disable the signal for object modifications to save resources.
    SQLALCHEMY_TRACK_MODIFICATIONS = False
