from flask import Flask
from app import create_app

# Instantiate a Flask application using the application factory pattern.
app = create_app()

# This condition checks whether the script is being run directly (not imported).
if __name__ == "__main__":
    # Run the Flask app with debug mode enabled to facilitate debugging during development.
    app.run(debug=True)
